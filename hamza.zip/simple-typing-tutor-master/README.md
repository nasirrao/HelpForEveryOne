simple-typing-tutor
===================

A typing tutor written in java.

You can download it from http://homepages.iitb.ac.in/~maxweldsouza/stt.html
